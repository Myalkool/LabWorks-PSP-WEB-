package Second;

public class Main {
    public static void main(String[] args) {
        Library med = new Library("Оформление книг");
        med.setVisible(true);
        med.setResizable(false);
        med.setLocationRelativeTo(null);
    }
}
