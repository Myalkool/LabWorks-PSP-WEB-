package First;


public class Main {
    public static void main(String[] args) {
        MyApp med = new MyApp("Списки");
        med.setVisible(true);
        med.setResizable(false);
        med.setLocationRelativeTo(null);
    }
}